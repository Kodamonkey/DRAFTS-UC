"""Wrapper for running the refactored Effelsberg FRB detection pipeline."""
from DRAFTS.pipeline import run_pipeline

if __name__ == "__main__":
    run_pipeline()
